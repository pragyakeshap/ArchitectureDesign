package com.nuvalence.arch.shapes.stepdef;

import com.nuvalence.arch.shapes.model.Point;
import com.nuvalence.arch.shapes.model.Rectangle;
import com.nuvalence.arch.shapes.util.ShapesUtil;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import org.junit.Assume;
import org.slf4j.LoggerFactory;

import java.util.Properties;

public class RectangleStepDefinition {
    private static final org.slf4j.Logger SYS_LOGGER = LoggerFactory.getLogger(RectangleStepDefinition.class);
    private static Rectangle rect1;
    private static Rectangle rect2;

    @Before("@ExcludeProdFlow")
    public void skipScenario() {
       // TODO : Adding placeholder method if we want to skip some scenarios
    }

    @Given("Co-ordinates of two rectangles are loaded from properties files")
    public void getRectangles() throws Exception {
        SYS_LOGGER.info("Loading all the required properties");
        Properties prop = ShapesUtil.loadRectangleProperties();
        String d1 = prop.getProperty("rectangle1.intersection.l.x");
        String d2 = prop.getProperty("rectangle1.intersection.l.y");
        String d3 = prop.getProperty("rectangle1.intersection.r.x");
        String d4 = prop.getProperty("rectangle1.intersection.r.y");

        String d5 = prop.getProperty("rectangle2.intersection.l.x");
        String d6 = prop.getProperty("rectangle2.intersection.l.y");
        String d7 = prop.getProperty("rectangle2.intersection.r.x");
        String d8 = prop.getProperty("rectangle2.intersection.r.y");


        // Rectangle one co-ordinates
        Point l1 = new Point(Integer.parseInt(d1), Integer.parseInt(d2));
        Point r1 = new Point(Integer.parseInt(d3), Integer.parseInt(d4));

        // Rectangle two co-ordinates
        Point l2 = new Point(Integer.parseInt(d5), Integer.parseInt(d6));
        Point r2 = new Point(Integer.parseInt(d7), Integer.parseInt(d8));

       /* Rectangle rec1 = new Rectangle(l1, r1);
        Rectangle rec2 = new Rectangle(l2, r2);*/
    }

    @When("Intersection API is called to check whether two rectangles intersect or not")
    public void callCheckIntersectionAPI(){
        // Call the localhost service url
    }
}
