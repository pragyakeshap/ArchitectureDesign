package com.nuvalence.arch.shapes.util;

import com.nuvalence.arch.shapes.model.Rectangle;

import java.io.InputStream;
import java.util.Properties;

public class ShapesUtil {

    /**
     * This method is used to load property files containing test data for the specified env
     * @return
     * @throws Exception
     */
    public static Properties loadRectangleProperties() throws Exception {
        InputStream input = null;
        Properties prop = null;
        String integrationTestEnv = null;
        try {
            //integrationTestEnv = System.getProperty("integration.test.env");
            integrationTestEnv = "DEV";
            input = Rectangle.class.getClassLoader()
                    .getResourceAsStream("rectangle-int-tests-" + integrationTestEnv + ".properties");

            prop = new Properties();
            prop.load(input);
        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception("Unable to read the properties file for the environment - " +integrationTestEnv);
        } finally {
            input.close();
        }
        return prop;
    }
}
