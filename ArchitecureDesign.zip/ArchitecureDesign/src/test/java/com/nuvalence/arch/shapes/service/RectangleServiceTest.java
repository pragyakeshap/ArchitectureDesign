package com.nuvalence.arch.shapes.service;

import com.nuvalence.arch.shapes.model.Rectangle;
import com.nuvalence.arch.shapes.model.Response;
import com.nuvalence.arch.shapes.service.RectangleService;
import com.nuvalence.arch.shapes.util.ShapesUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.context.request.WebRequest;

import javax.servlet.http.HttpServletRequest;
import java.util.Properties;
import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class RectangleServiceTest {

    private static final String SUCCESS = "Success";

    @InjectMocks
    RectangleService rectangleService;

    @Mock
    WebRequest request;

    @Mock
    HttpServletRequest httpServletRequest;

    String rec1 , rec2 , rec3 , rec4, rec5 , rec6 , rec7;

    @Before
    public void setUp() throws Exception {
        Properties prop = ShapesUtil.loadRectangleProperties();
        rec1 = prop.getProperty("rect1.intersection.dimensions");
        rec2 = prop.getProperty("rect2.intersection.dimensions");
        rec3 = prop.getProperty("rect3.nonIntersecting.dimensions");
        rec4 = prop.getProperty("rect4.nonContained.dimensions");
        rec5 = prop.getProperty("rect5.adjacency.subline.dimensions");
        rec6 = prop.getProperty("rect6.adjacency.proper.dimensions");
        rec7 = prop.getProperty("rect7.adjacency.partial.dimensions");
    }

    @Test
    public final void testRectangleIntersectionShouldReturnCorrectDimensions() {

        // Check if rectangles intersect
        boolean intersect = rectangleService.checkIntersection(rec1 ,rec2);
        assertTrue(intersect);

        // If they intersect, find intersecting rectangle
        Rectangle actualResponse = rectangleService.findIntersectingRectangle(rec1, rec2);

        Rectangle expectedResponse = new Rectangle(120,100,80,100);
        assertEquals(expectedResponse.toString() , actualResponse.toString());
    }

    @Test
    public final void testNonIntersectingRectanglesShouldReturnFalse(){
        boolean intersect = rectangleService.checkIntersection(rec1 ,rec3);
        assertFalse(intersect);
    }

    @Test
    public final void testNonContainedRectanglesShouldReturnFalse(){
        boolean containment = rectangleService.checkContainment(rec1 ,rec3);
        assertFalse(containment);
    }

    @Test
    public final void testNonContainedRectanglesShouldReturnTrue(){
        boolean containment = rectangleService.checkContainment(rec1 ,rec4);
        assertTrue(containment);
    }

    @Test
    public final void testAdjacentSublineShouldReturnSublineEnum(){
        AdjacencyTypes type = rectangleService.checkAdjacency(rec1 ,rec5);
        assertEquals(type, AdjacencyTypes.ADJACENT_SUB_LINE);
    }

    @Test
    public final void testAdjacentProperShouldReturnProperEnum(){
        AdjacencyTypes type = rectangleService.checkAdjacency(rec1 ,rec6);
        assertEquals(type, AdjacencyTypes.ADJACENT_PROPER);
    }

    @Test
    public final void testAdjacentPartialShouldReturnPartialEnum(){
        AdjacencyTypes type = rectangleService.checkAdjacency(rec1 ,rec7);
        assertEquals(type, AdjacencyTypes.ADJACENT_PARTIAL);
    }

    @Test
    public final void testNonAdjacentShouldReturnNonAdjacentEnum(){
        AdjacencyTypes type = rectangleService.checkAdjacency(rec1 ,rec3);
        assertEquals(type, AdjacencyTypes.NON_ADJACENT);
    }
}


