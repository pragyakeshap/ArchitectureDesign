package com.nuvalence.arch.shapes.controller;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(glue = {"com.nuvalence.arch.shapes.controller.stepdef"},features = "src/test/resources/feature",monochrome = true, plugin = {"pretty", "html:target/cucumber/report", "rerun:target/rerun.txt", "json:target/cucumber/cucumber.json" }, snippets = SnippetType.CAMELCASE)
public class CucumberRunner {

}

