package com.nuvalence.arch.shapes.model;

public class RectangleTest {
}
