package com.nuvalence.arch.shapes.model;

/**
 * This call represents a rectangle.
 * The variables x and y represent co-ordinates of top left corner of the rectangle.
 * The x and y co-ordinate values increase as they move to the right and down respectively.
 * The variables w and h represent the width and height of the rectangle.
 */


public class Rectangle {

    /**
     * The X coordinate of the top-left corner of the rectangle.
     */
    int x;

    /**
     * The Y coordinate of the top-left corner of the rectangle.
     */
    int y;

    /**
     * The width of the rectangle.
     */
    int width;


    /**
     * The height of the rectangle.
     */
    int height;

    /**
     * Getter for x
     * @return
     */
    public int getX() {
        return x;
    }

    /**
     * Setter for x
     * @param x
     */
    public void setX(int x) {
        this.x = x;
    }

    /**
     * Getter for y
     * @return
     */
    public int getY() {
        return y;
    }

    /**
     * Setter for y
     * @return
     */
    public void setY(int y) {
        this.y = y;
    }

    /**
     * Getter for width
     * @return
     */
    public int getWidth() {
        return width;
    }

    /**
     * Setter for width
     * @return
     */
    public void setWidth(int width) {
        this.width = width;
    }

    /**
     * Getter for height
     * @return
     */
    public int getHeight() {
        return height;
    }

    /**
     * Setter for height
     * @return
     */
    public void setHeight(int height) {
        this.height = height;
    }

    /**
     * Default constructor - needed by Spring to initialize the bean
     */
    public Rectangle() {

    }

    /**
     * Initializes a new instance of <code>Rectangle</code> from the
     * coordinates of the specified rectangle.
     *
     * @param r the rectangle to copy from
     */
    public Rectangle(Rectangle r) {
        x = r.x;
        y = r.y;
        width = r.width;
        height = r.height;
    }

    /**
     * Initializes a new instance of <code>Rectangle</code> from the specified
     * inputs.
     *
     * @param x      the X coordinate of the top left corner
     * @param y      the Y coordinate of the top left corner
     * @param width  the width of the rectangle
     * @param height the height of the rectangle
     */
    public Rectangle(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    /**
     * Initializes a new instance of <code>Rectangle</code> with a top-left
     * corner represented by the specified point and the width and height
     *
     * @param p the upper left corner of the rectangle
     */
    public Rectangle(Point p, int w, int h) {
        x = p.x;
        y = p.y;
        width = w;
        height = h;
    }

    /**
     * Returns a string representation of rectangle in the form
     * getClass().getName() + "[x=" + x + ",y=" + y + ",w=" + width
     * + ",h=" + height + ']'
     *
     * @return a string representation of this rectangle
     */
    public String toString() {
        return " Rectangle [x=" + x + ",y=" + y + ",w=" + width + ",h=" + height + ']';
    }

}
