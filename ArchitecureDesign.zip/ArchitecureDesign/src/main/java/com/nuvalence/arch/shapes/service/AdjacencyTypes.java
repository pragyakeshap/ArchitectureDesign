package com.nuvalence.arch.shapes.service;

public enum AdjacencyTypes {

    ADJACENT_SUB_LINE("Adjacent - Sub Line"),
    ADJACENT_PROPER("Adjacent - Proper"),
    ADJACENT_PARTIAL("Adjacent - Partial"),
    NON_ADJACENT("Not Adjacent");

    private final String adjacentType;

    private AdjacencyTypes(String adjacentType) {
        this.adjacentType = adjacentType;
    }

    @Override
    public String toString() {
        return adjacentType;
    }
}
