package com.nuvalence.arch.shapes; /**
 * @author pragya.keshap
 */


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ImportResource;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2

public class ArchitectureDesignApplication {

    public static void main(String[] args) throws Exception {
        SpringApplication.run(ArchitectureDesignApplication.class,args);
    }
}
