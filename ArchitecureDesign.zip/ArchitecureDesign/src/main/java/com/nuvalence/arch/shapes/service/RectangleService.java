package com.nuvalence.arch.shapes.service;

import com.nuvalence.arch.shapes.model.Rectangle;
import org.springframework.stereotype.Service;

@Service
public class RectangleService {

    /**
     * Moves the location of this rectangle by setting its upper left
     * corner to the specified coordinates.
     *
     * @param x the new X coordinate for this rectangle
     * @param y the new Y coordinate for this rectangle
     */
    public Rectangle move(Rectangle r, int x, int y) {
        r.setX(x);
        r.setY(y);
        return r;
    }

    /**
     * Wrapper method over intersects method - converts string dimension to rectangle objects and passes on
     *
     * @param r1
     * @param r2
     * @return
     */
    public boolean checkContainment(String r1, String r2) {
        Rectangle rec1 = getRectangleFromDimensions(r1);
        Rectangle rec2 = getRectangleFromDimensions(r2);
        return contains(rec1, rec2);

    }


    /**
     * Checks whether all points in the given rectangle are contained in this
     * rectangle.
     *
     * @param r1
     * @param r2
     * @return true if the parameters are contained in this rectangle
     */
    public boolean contains(Rectangle r1, Rectangle r2) {
        return r2.getWidth() > 0 && r2.getHeight() > 0 && r1.getWidth() > 0 && r1.getHeight() > 0
                && r2.getX() >= r1.getX() && r2.getX() + r2.getWidth() <= r1.getX() + r1.getWidth()
                && r2.getY() >= r1.getY() && r2.getY() + r2.getHeight() <= r1.getY() + r1.getHeight();
    }

    /**
     * Checks whether or not the specified rectangle intersects this rectangle.
     * This means the two rectangles share at least one internal point.
     *
     * @param r1
     * @param r2
     * @return
     */
    public boolean intersects(Rectangle r1, Rectangle r2) {
        return r2.getWidth() > 0 && r2.getHeight() > 0 && r1.getWidth() > 0 && r1.getHeight() > 0
                && r2.getX() < r1.getX() + r1.getWidth() && r2.getX() + r2.getWidth() > r1.getX()   // To make sure that one x co-ordinate of rectangle b lies within a.x , a.x +a.width and that b.x + b.width lies outside the rectangle a
                && r2.getY() < r1.getY() + r1.getHeight() && r2.getY() + r2.getHeight() > r1.getY();
    }

    /**
     * Method to find dimensions of rectangle created by intersection of two given rectangles
     *
     * @param r1
     * @param r2
     * @return
     */
    public Rectangle findIntersectingRectangle(String r1, String r2) {
        Rectangle rec1 = getRectangleFromDimensions(r1);
        Rectangle rec2 = getRectangleFromDimensions(r2);
        int x = Math.max(rec1.getX(), rec2.getX());
        int y = Math.max(rec1.getY(), rec2.getY());
        int maxX = Math.min(rec1.getX() + rec1.getWidth(), rec2.getX() + rec2.getWidth());
        int maxY = Math.min(rec1.getY() + rec1.getHeight(), rec2.getY() + rec2.getHeight());

        return new Rectangle(x, y, maxX - x, maxY - y);
    }

    /**
     * Wrapper method over intersects method - converts string dimension to rectangle objects and passes on
     *
     * @param r1
     * @param r2
     * @return
     */
    public boolean checkIntersection(String r1, String r2) {
        Rectangle rec1 = getRectangleFromDimensions(r1);
        Rectangle rec2 = getRectangleFromDimensions(r2);
        return intersects(rec1, rec2);

    }

    /**
     * Creates rectangle from dimensions separated by comma
     *
     * @param recDimensions
     * @return
     */
    public Rectangle getRectangleFromDimensions(String recDimensions) {
        String[] dimension1 = recDimensions.split(",");
        return new Rectangle(Integer.parseInt(dimension1[0]), Integer.parseInt(dimension1[1]), Integer.parseInt(dimension1[2]), Integer.parseInt(dimension1[3]));
    }


    /**
     * Wrapper method over intersects method - converts string dimension to rectangle objects and passes on
     *
     * @param r1
     * @param r2
     * @return
     */
    public AdjacencyTypes checkAdjacency(String r1, String r2) {
        Rectangle rec1 = getRectangleFromDimensions(r1);
        Rectangle rec2 = getRectangleFromDimensions(r2);
        return adjacent(rec1, rec2);

    }


    /**
     * Checks whether all points in the given rectangle are contained in this
     * rectangle.
     *
     * @param r1
     * @param r2
     * @return true if the parameters are contained in this rectangle
     */
    public AdjacencyTypes adjacent(Rectangle r1, Rectangle r2) {

        // check intersection, if r1 and r2 intersect, then they are not adjacent
        if (intersects(r1, r2) || contains(r1, r2)) {
            return AdjacencyTypes.NON_ADJACENT;
        }
        // Proper Adjacent  - // check if width is same and then check for one common point
        else if ((r1.getWidth() == r2.getWidth() && r1.getX() == r2.getX() && r1.getY() == r2.getY() + r2.getHeight())
                || (r1.getHeight() == r2.getHeight() && r1.getX() + r1.getWidth() == r2.getX() && r2.getY() == r2.getY())
                || (r1.getX() == r1.getX() && r1.getY() == r2.getY()) && (r1.getHeight() == r2.getHeight() || r1.getWidth() == r2.getWidth())
        ) {
            return AdjacencyTypes.ADJACENT_PROPER;
        }
        // partial adjacency
        else if ( (r2.getX() == r1.getX() + r1.getWidth() )
                && (r1.getY() > r2.getY())
                && (r2.getY() + r2.getHeight() < r1.getY() + r1.getHeight()))
        {
            return AdjacencyTypes.ADJACENT_PARTIAL;
        }

        // subline adjacency
        else if (r1.getX() + r1.getWidth() == r2.getX()
                && r2.getY() > r1.getY()
                && r2.getY() + r2.getHeight() < r1.getY() + r1.getHeight()) {
            return AdjacencyTypes.ADJACENT_SUB_LINE;
        }

        return AdjacencyTypes.NON_ADJACENT;
    }


    // TODO add isEmpty() method to check if rectangle is empty
}
