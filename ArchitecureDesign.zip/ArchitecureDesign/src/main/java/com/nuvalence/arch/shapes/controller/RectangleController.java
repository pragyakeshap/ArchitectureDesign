package com.nuvalence.arch.shapes.controller;


import com.nuvalence.arch.shapes.model.Rectangle;
import com.nuvalence.arch.shapes.model.RectangleRequestBody;
import com.nuvalence.arch.shapes.model.Response;
import com.nuvalence.arch.shapes.service.AdjacencyTypes;
import com.nuvalence.arch.shapes.service.RectangleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;

@RestController
@RequestMapping(path = "/rectangle")
@EnableAutoConfiguration
public class RectangleController {


    @Autowired
    WebRequest request;

    @Autowired
    RectangleService rectangleService;


    @PostMapping(path = "/checkIntersection",
            produces = "application/json",
            consumes = {MediaType.APPLICATION_FORM_URLENCODED_VALUE})
    public ResponseEntity<Response> checkIntersection(RectangleRequestBody requestBody) {

        //TODO : Implement null validation

        Rectangle intersectionRect;
        String r1 = requestBody.getRec1();
        String r2 = requestBody.getRec2();
        boolean intersect = rectangleService.checkIntersection(r1, r2);
        if (intersect) {
            intersectionRect = rectangleService.findIntersectingRectangle(r1, r2);
            return new ResponseEntity<>(new Response.Builder().rectangle(intersectionRect.toString()).message("The rectangles are intersecting !!").build(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(new Response.Builder().message("Rectangles do not intersect").build(), HttpStatus.BAD_REQUEST);
        }

    }

    @PostMapping(path = "/checkContainment",
            produces = "application/json",
            consumes = {MediaType.APPLICATION_FORM_URLENCODED_VALUE})
    public ResponseEntity<Response> checkContainment(RectangleRequestBody requestBody) {

        //TODO : Implement null validation

        String r1 = requestBody.getRec1();
        String r2 = requestBody.getRec2();
        boolean containment = rectangleService.checkContainment(r1, r2);
        if (containment) {
            return new ResponseEntity<>(new Response.Builder().rectangle(null).message("Rectangle is wholly contained within other rectangle !!").build(), HttpStatus.OK);
        } else {
            boolean intersect = rectangleService.checkIntersection(r1, r2);
            if (intersect) {
                return new ResponseEntity<>(new Response.Builder().message("The rectangles are intersecting !!").build(), HttpStatus.BAD_REQUEST);
            }
            return new ResponseEntity<>(new Response.Builder().rectangle(null).message("Rectangles is not contained within the other rectangle !!").build(), HttpStatus.BAD_REQUEST);
        }

    }

    @PostMapping(path = "/checkAdjacency",
            produces = "application/json",
            consumes = {MediaType.APPLICATION_FORM_URLENCODED_VALUE})
    public ResponseEntity<Response> checkAdjacency(RectangleRequestBody requestBody) {

        //TODO : Implement null validation

        String r1 = requestBody.getRec1();
        String r2 = requestBody.getRec2();
        AdjacencyTypes adj = rectangleService.checkAdjacency(r1, r2);
        return new ResponseEntity<>(new Response.Builder().message(adj.toString()).build(), HttpStatus.OK);

    }


}
