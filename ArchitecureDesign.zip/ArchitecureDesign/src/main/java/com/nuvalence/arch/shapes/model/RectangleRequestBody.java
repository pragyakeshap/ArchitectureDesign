package com.nuvalence.arch.shapes.model;

public class RectangleRequestBody {
    private String rec1;
    private String rec2;

    public String getRec1() {
        return rec1;
    }

    public void setRec1(String rec1) {
        this.rec1 = rec1;
    }

    public String getRec2() {
        return rec2;
    }

    public void setRec2(String rec2) {
        this.rec2 = rec2;
    }
}
