package com.nuvalence.arch.shapes.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Response {


    @JsonProperty("intersectionRectangle")
    private String rectangle;

    @JsonProperty("responseMessage")
    private String message;

    public String getMessage() {
        return message;
    }


    public String getRectangle() {
        return rectangle;
    }

    public static class Builder{
        private String rectangle;
        private String message;

        public Builder rectangle(String rect){
            rectangle = rect;
            return this;
        }

        public Builder message(String mess){
            message = mess;
            return this;
        }

        public Response build(){
            return new Response(this);
        }



    }

    protected Response(Builder builder) {
        this.rectangle = builder.rectangle;
        this.message = builder.message;
    }
}
